import { useState } from "react";
import {
  Search,
  User,
  PawPrint,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Syringe,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Sparkles,
  Plus,
  ArrowUpRight,
  Filter,
  Check
} from "lucide-react";
import { TODAY, uid, addLog, petName, ICON, I } from "../lib.jsx";
import { api } from "../api.js";
import { petAge } from "./owner/ui.jsx";
import { formatSpeciesLabel, computeAgeDetails, normalizeSpecies } from "../preventiveSchedule.js";
import PetCardModal from "./PetCardModal.jsx";
import InClinicRegistration from "./InClinicRegistration.jsx";
import CheckInModal from "./CheckInModal.jsx";

function getPetVaccState(petId, vaccList) {
  const mine = (vaccList || []).filter(v => v.petId === petId);
  if (!mine.length) {
    return { label: "No records yet", status: "none", color: "#64748b", bg: "#f1f5f9", border: "#e2e8f0" };
  }

  const now = new Date(TODAY + "T00:00:00");
  let overdueCount = 0;
  let dueSoonCount = 0;
  let nextUpcoming = null;

  for (const v of mine) {
    if (!v.done && v.nextDue) {
      const dt = new Date(v.nextDue + "T00:00:00");
      const diff = Math.ceil((dt - now) / (1000 * 60 * 60 * 24));
      if (diff < 0) {
        overdueCount++;
      } else if (diff <= 14) {
        dueSoonCount++;
      }
      if (!nextUpcoming || v.nextDue < nextUpcoming.nextDue) {
        nextUpcoming = v;
      }
    }
  }

  if (overdueCount > 0) {
    return {
      label: `${overdueCount} Overdue`,
      status: "overdue",
      color: "#b91c1c",
      bg: "#fef2f2",
      border: "#fecaca",
      next: nextUpcoming
    };
  }
  if (dueSoonCount > 0) {
    return {
      label: `${dueSoonCount} Due soon`,
      status: "dueSoon",
      color: "#b45309",
      bg: "#fffbeb",
      border: "#fde68a",
      next: nextUpcoming
    };
  }
  return {
    label: "Up to date",
    status: "ok",
    color: "#15803d",
    bg: "#f0fdf4",
    border: "#bbf7d0",
    next: nextUpcoming
  };
}

export default function ClientsAndPatientsPage({ db, setDb, me, go, say }) {
  const [tab, setTab] = useState("patients"); // 'patients' | 'owners'
  const [search, setSearch] = useState("");
  const [speciesFilter, setSpeciesFilter] = useState("all");
  const [vaccFilter, setVaccFilter] = useState("all");
  const [cardPetId, setCardPetId] = useState(null);
  const [showWalkIn, setShowWalkIn] = useState(false);
  const [addPetForOwner, setAddPetForOwner] = useState(null);
  const [checkInAppt, setCheckInAppt] = useState(null);

  const pets = db.pets || [];
  const owners = db.owners || [];
  const vaccs = db.vacc || db.vaccs || [];

  const handleCheckInPet = async (pet) => {
    let appt = (db.appts || []).find(a => a.petId === pet.id && a.date === TODAY && a.status !== "Cancelled");
    if (!appt) {
      const timeStr = new Date().toLocaleTimeString("en-PH", { hour12: false, hour: "2-digit", minute: "2-digit" });
      const newApptPayload = {
        id: "a_" + uid(),
        petId: pet.id,
        vetId: "v1",
        date: TODAY,
        time: timeStr,
        reason: "Walk-in Consultation & Check-in",
        status: "Scheduled",
        billingStatus: "Unbilled",
        amount: 600,
        actorName: me?.name || "Staff",
        actorRole: me?.role || "assistant"
      };
      try {
        await api.post("/api/appointments", newApptPayload);
      } catch (err) {
        console.warn("Backend appointment fallback:", err);
      }
      appt = newApptPayload;
      setDb(p => ({
        ...p,
        appts: [appt, ...(p.appts || [])],
        log: addLog(p, me, `Initiated walk-in arrival check-in for ${pet.name}.`)
      }));
    }
    setCheckInAppt(appt);
  };

  // Filtered Pets
  const filteredPets = pets.filter(p => {
    const o = owners.find(x => x.id === p.ownerId || x.userId === p.ownerId) || {};
    const norm = normalizeSpecies(p.species);

    if (speciesFilter !== "all" && norm !== speciesFilter) return false;

    const vs = getPetVaccState(p.id, vaccs);
    if (vaccFilter !== "all" && vs.status !== vaccFilter) return false;

    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    return (
      (p.name && p.name.toLowerCase().includes(q)) ||
      (p.breed && p.breed.toLowerCase().includes(q)) ||
      (p.species && p.species.toLowerCase().includes(q)) ||
      (p.vaccinationCardId && p.vaccinationCardId.toLowerCase().includes(q)) ||
      (o.name && o.name.toLowerCase().includes(q)) ||
      (o.phone && o.phone.includes(q)) ||
      (o.email && o.email.toLowerCase().includes(q))
    );
  });

  // Filtered Owners
  const filteredOwners = owners.filter(o => {
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    const ownerPets = pets.filter(p => p.ownerId === o.id || p.ownerId === o.userId);
    return (
      (o.name && o.name.toLowerCase().includes(q)) ||
      (o.phone && o.phone.includes(q)) ||
      (o.email && o.email.toLowerCase().includes(q)) ||
      (o.address && o.address.toLowerCase().includes(q)) ||
      ownerPets.some(p => p.name.toLowerCase().includes(q))
    );
  });

  return (
    <div>
      {/* Top Banner Toolbar */}
      <div style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "14px",
        marginBottom: "16px",
        flexWrap: "wrap",
        background: "#ffffff",
        padding: "14px 18px",
        borderRadius: "14px",
        border: "1px solid #e2e8f0",
        boxShadow: "0 1px 3px rgba(0,0,0,0.03)"
      }}>
        {/* Tabs: Patients vs Clients */}
        <div style={{ display: "inline-flex", background: "#f1f5f9", padding: "3px", borderRadius: "10px", border: "1px solid #e2e8f0" }}>
          <button
            type="button"
            onClick={() => setTab("patients")}
            style={{
              padding: "7px 16px",
              fontSize: "13px",
              fontWeight: 700,
              borderRadius: "8px",
              border: "none",
              cursor: "pointer",
              background: tab === "patients" ? "var(--navy, #1e3a8a)" : "transparent",
              color: tab === "patients" ? "#fff" : "#475569",
              display: "flex",
              alignItems: "center",
              gap: "6px",
              transition: "all 0.15s ease",
            }}
          >
            <PawPrint size={15} />
            <span>All Patients ({pets.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setTab("owners")}
            style={{
              padding: "7px 16px",
              fontSize: "13px",
              fontWeight: 700,
              borderRadius: "8px",
              border: "none",
              cursor: "pointer",
              background: tab === "owners" ? "var(--navy, #1e3a8a)" : "transparent",
              color: tab === "owners" ? "#fff" : "#475569",
              display: "flex",
              alignItems: "center",
              gap: "6px",
              transition: "all 0.15s ease",
            }}
          >
            <User size={15} />
            <span>Clients &amp; Households ({owners.length})</span>
          </button>
        </div>

        {/* Action Button */}
        <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
          <button
            className="btn gold"
            onClick={() => setShowWalkIn(true)}
            style={{ display: "flex", alignItems: "center", gap: "6px", fontWeight: 700, padding: "8px 16px", fontSize: "13.5px" }}
          >
            <Plus size={16} /> + Register Walk-in (Owner &amp; Pet)
          </button>
        </div>
      </div>

      {/* Search & Filters */}
      <div style={{
        background: "#ffffff",
        padding: "12px 18px",
        borderRadius: "12px",
        border: "1px solid #e2e8f0",
        marginBottom: "16px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "12px",
        flexWrap: "wrap"
      }}>
        <div style={{ position: "relative", flex: "1 1 260px", maxWidth: "420px" }}>
          <Search size={16} style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "#94a3b8" }} />
          <input
            type="search"
            placeholder={tab === "patients" ? "Search patient, owner name, phone, card #..." : "Search client name, phone, address, pet name..."}
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ width: "100%", padding: "8px 12px 8px 36px", fontSize: "13px", borderRadius: "8px", border: "1px solid #cbd5e1" }}
          />
        </div>

        {tab === "patients" && (
          <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }}>
            <label style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "12.5px", margin: 0, fontWeight: 600, color: "#475569" }}>
              <Filter size={14} />
              <select
                value={speciesFilter}
                onChange={e => setSpeciesFilter(e.target.value)}
                style={{ padding: "6px 10px", fontSize: "12.5px", borderRadius: "6px", border: "1px solid #cbd5e1" }}
              >
                <option value="all">All Species</option>
                <option value="Canine">Dogs (Canine)</option>
                <option value="Feline">Cats (Feline)</option>
                <option value="Lagomorph">Rabbits (Lagomorph)</option>
                <option value="Rodent">Rodents</option>
                <option value="Avian">Birds (Avian)</option>
                <option value="Other">Others</option>
              </select>
            </label>

            <select
              value={vaccFilter}
              onChange={e => setVaccFilter(e.target.value)}
              style={{ padding: "6px 10px", fontSize: "12.5px", borderRadius: "6px", border: "1px solid #cbd5e1" }}
            >
              <option value="all">All Vaccine Statuses</option>
              <option value="ok">Up to date</option>
              <option value="dueSoon">Due soon (within 14 days)</option>
              <option value="overdue">Overdue</option>
            </select>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      {tab === "patients" ? (
        <section className="card" style={{ padding: "0", overflow: "hidden" }}>
          <div style={{ padding: "12px 18px", background: "#f8fafc", borderBottom: "1px solid #e2e8f0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: "12.5px", color: "#475569" }}>
              <b>Tip:</b> Click any row to open the pet&rsquo;s official <b>Digital Vaccination Card</b>, review shots, or print access slips.
            </span>
            <span style={{ fontSize: "12.5px", fontWeight: 700, color: "var(--navy)" }}>
              {filteredPets.length} patient(s) found
            </span>
          </div>

          {filteredPets.length ? (
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", fontSize: "13px", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ textAlign: "left", background: "#f8fafc", color: "#475569", borderBottom: "2px solid #e2e8f0" }}>
                    <th style={{ padding: "12px 14px" }}>Patient Profile</th>
                    <th style={{ padding: "12px 14px" }}>Registered Owner &amp; Contact</th>
                    <th style={{ padding: "12px 14px" }}>Vaccination Card</th>
                    <th style={{ padding: "12px 14px" }}>Immunization Status</th>
                    <th style={{ padding: "12px 14px", textAlign: "right" }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPets.map(p => {
                    const o = owners.find(x => x.id === p.ownerId || x.userId === p.ownerId) || {};
                    const age = p.birth ? petAge(p.birth) : "";
                    const vs = getPetVaccState(p.id, vaccs);

                    return (
                      <tr
                        key={p.id}
                        onClick={() => setCardPetId(p.id)}
                        style={{
                          borderBottom: "1px solid #f1f5f9",
                          cursor: "pointer",
                          transition: "background 0.15s ease",
                        }}
                        onMouseEnter={e => (e.currentTarget.style.background = "#f0f9ff")}
                        onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
                        title="Click row to open Digital Vaccination Card"
                      >
                        {/* Patient info */}
                        <td style={{ padding: "12px 14px" }}>
                          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <div style={{ width: "36px", height: "36px", borderRadius: "50%", background: "#e0f2fe", color: "#0369a1", display: "grid", placeItems: "center", fontSize: "18px" }}>
                              <I e={ICON[p.species] || "🐾"} size={18} />
                            </div>
                            <div>
                              <b style={{ color: "var(--navy)", fontSize: "14px", textDecoration: "underline" }}>
                                {p.name}
                              </b>
                              <div style={{ fontSize: "12px", color: "#64748b" }}>
                                {formatSpeciesLabel(p.species)} &bull; {p.breed || "Mixed"} {age ? `&bull; ${age}` : ""}
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Owner info */}
                        <td style={{ padding: "12px 14px" }}>
                          <b style={{ color: "#1e293b" }}>{o.name || "Walk-in Client"}</b>
                          <div style={{ fontSize: "12px", color: "#64748b", display: "flex", alignItems: "center", gap: "6px" }}>
                            <span style={{ display: "inline-flex", alignItems: "center", gap: "4px" }}><Phone size={12} /> {o.phone || "No phone"}</span>
                            {o.address && <span>&bull; {o.address}</span>}
                          </div>
                        </td>

                        {/* Card ID */}
                        <td style={{ padding: "12px 14px" }}>
                          <span style={{
                            display: "inline-flex",
                            alignItems: "center",
                            gap: "4px",
                            background: "#ecfdf5",
                            color: "#065f46",
                            border: "1px solid #a7f3d0",
                            padding: "3px 8px",
                            borderRadius: "6px",
                            fontSize: "11.5px",
                            fontFamily: "monospace",
                            fontWeight: 700
                          }}>
                            {p.vaccinationCardId || "VACC-UNISSUED"}
                          </span>
                        </td>

                        {/* Vaccine status */}
                        <td style={{ padding: "12px 14px" }}>
                          <span style={{
                            display: "inline-block",
                            padding: "3px 8px",
                            borderRadius: "6px",
                            fontSize: "11.5px",
                            fontWeight: 700,
                            background: vs.bg,
                            color: vs.color,
                            border: `1px solid ${vs.border}`
                          }}>
                            {vs.label}
                          </span>
                          {vs.next && (
                            <small style={{ display: "block", color: "#64748b", marginTop: "2px", fontSize: "11px" }}>
                              Next: {vs.next.vaccine} ({vs.next.nextDue})
                            </small>
                          )}
                        </td>

                        {/* Action link */}
                        <td style={{ padding: "12px 14px", textAlign: "right" }}>
                          <div style={{ display: "inline-flex", gap: "6px", alignItems: "center" }} onClick={e => e.stopPropagation()}>
                            <button
                              type="button"
                              className="btn sm"
                              onClick={() => handleCheckInPet(p)}
                              style={{
                                padding: "4px 8px",
                                fontSize: "11.5px",
                                background: "#f0fdf4",
                                color: "#166534",
                                border: "1px solid #86efac",
                                fontWeight: 700,
                                borderRadius: "6px"
                              }}
                              title="Check in for today's visit with vitals"
                            >
                              Check In
                            </button>
                            <button
                              type="button"
                              className="btn sm ghost"
                              onClick={() => {
                                go ? go("cal") : null;
                                say && say(`Opening calendar to book visit for ${p.name}...`);
                              }}
                              style={{
                                padding: "4px 8px",
                                fontSize: "11.5px",
                                color: "#1e3a8a",
                                border: "1px solid #cbd5e1",
                                fontWeight: 600,
                                borderRadius: "6px"
                              }}
                              title="Schedule appointment in calendar"
                            >
                              Book
                            </button>
                            <button
                              type="button"
                              className="btn sm ghost"
                              onClick={() => setCardPetId(p.id)}
                              style={{
                                padding: "4px 8px",
                                fontSize: "11.5px",
                                color: "var(--navy)",
                                border: "1px solid #bfdbfe",
                                background: "#eff6ff",
                                fontWeight: 600,
                                borderRadius: "6px"
                              }}
                              title="Open Official Digital Vaccination Card"
                            >
                              Card
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="empty sm" style={{ padding: "32px 16px", textAlign: "center" }}>
              No animal patients found matching your search criteria.
            </div>
          )}
        </section>
      ) : (
        /* Household / Client-First View */
        <section className="card" style={{ padding: "0", overflow: "hidden" }}>
          <div style={{ padding: "12px 18px", background: "#f8fafc", borderBottom: "1px solid #e2e8f0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: "12.5px", color: "#475569" }}>
              Registered pet owners, client accounts, contact details, and their registered animals.
            </span>
            <span style={{ fontSize: "12.5px", fontWeight: 700, color: "var(--navy)" }}>
              {filteredOwners.length} client(s) found
            </span>
          </div>

          {filteredOwners.length ? (
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", fontSize: "13px", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ textAlign: "left", background: "#f8fafc", color: "#475569", borderBottom: "2px solid #e2e8f0" }}>
                    <th style={{ padding: "12px 14px" }}>Client Name &amp; Contact</th>
                    <th style={{ padding: "12px 14px" }}>Address / Location</th>
                    <th style={{ padding: "12px 14px" }}>Registered Pets</th>
                    <th style={{ padding: "12px 14px", textAlign: "right" }}>Quick Access</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOwners.map(o => {
                    const ownerPets = pets.filter(p => p.ownerId === o.id || p.ownerId === o.userId);

                    return (
                      <tr key={o.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                        <td style={{ padding: "12px 14px" }}>
                          <b style={{ color: "var(--navy)", fontSize: "14px" }}>{o.name}</b>
                          <div style={{ fontSize: "12px", color: "#64748b", marginTop: "2px", display: "flex", alignItems: "center", gap: "8px" }}>
                            <span style={{ display: "inline-flex", alignItems: "center", gap: "4px" }}><Phone size={12} /> {o.phone || "No phone"}</span> &bull; <span style={{ display: "inline-flex", alignItems: "center", gap: "4px" }}><Mail size={12} /> {o.email || "No email"}</span>
                          </div>
                        </td>

                        <td style={{ padding: "12px 14px", color: "#475569" }}>
                          {o.address || "Metro Manila, PH"}
                        </td>

                        <td style={{ padding: "12px 14px" }}>
                          {ownerPets.length ? (
                            <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                              {ownerPets.map(p => (
                                <button
                                  key={p.id}
                                  type="button"
                                  onClick={() => setCardPetId(p.id)}
                                  style={{
                                    padding: "3px 8px",
                                    fontSize: "12px",
                                    borderRadius: "6px",
                                    border: "1px solid #bfdbfe",
                                    background: "#eff6ff",
                                    color: "#1e40af",
                                    fontWeight: 700,
                                    cursor: "pointer",
                                    display: "inline-flex",
                                    alignItems: "center",
                                    gap: "4px"
                                  }}
                                  title="Click to open pet's Digital Card"
                                >
                                  <span>{p.name}</span>
                                  <small style={{ fontWeight: 400, color: "#64748b" }}>({p.species})</small>
                                </button>
                              ))}
                            </div>
                          ) : (
                            <span style={{ color: "#94a3b8", fontSize: "12px" }}>No registered pets</span>
                          )}
                        </td>

                        <td style={{ padding: "12px 14px", textAlign: "right" }}>
                          <div style={{ display: "inline-flex", gap: "8px", alignItems: "center" }}>
                            <button
                              type="button"
                              className="btn sm gold"
                              onClick={() => setAddPetForOwner(o)}
                              style={{
                                padding: "4px 10px",
                                fontSize: "11.5px",
                                fontWeight: 700,
                                borderRadius: "6px",
                                display: "inline-flex",
                                alignItems: "center",
                                gap: "4px"
                              }}
                              title="Register a new pet linked to this client"
                            >
                              <Plus size={13} /> Add Pet
                            </button>
                            <button
                              type="button"
                              className="btn sm ghost"
                              onClick={() => {
                                go ? go("cal") : null;
                                say && say(`Opening calendar to book visit for ${o.name}...`);
                              }}
                              style={{
                                padding: "4px 10px",
                                fontSize: "11.5px",
                                fontWeight: 600,
                                color: "#1e3a8a",
                                border: "1px solid #cbd5e1",
                                borderRadius: "6px"
                              }}
                              title="Schedule appointment in calendar"
                            >
                              Book Visit
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="empty sm" style={{ padding: "32px 16px", textAlign: "center" }}>
              No client accounts found matching your search criteria.
            </div>
          )}
        </section>
      )}

      {/* Pet Card Modal Popup */}
      {cardPetId && (
        <PetCardModal
          petId={cardPetId}
          db={db}
          setDb={setDb}
          me={me}
          onClose={() => setCardPetId(null)}
          onCheckIn={() => setCardPetId(null)}
          onBill={() => setCardPetId(null)}
        />
      )}

      {/* In-Clinic Walk-in Registration Modal (New Client & Pet) */}
      {showWalkIn && (
        <InClinicRegistration
          db={db}
          setDb={setDb}
          me={me}
          onClose={() => setShowWalkIn(false)}
          onRegistered={({ pet, owner }) => {
            say && say(`Successfully registered ${owner?.name || "Client"} and issued card for ${pet?.name || "Patient"}!`);
            setShowWalkIn(false);
          }}
        />
      )}

      {/* Add Pet For Existing Client Modal */}
      {addPetForOwner && (
        <InClinicRegistration
          existingOwner={addPetForOwner}
          db={db}
          setDb={setDb}
          me={me}
          onClose={() => setAddPetForOwner(null)}
          onRegistered={({ pet, owner }) => {
            say && say(`Successfully added ${pet?.name || "Patient"} to ${owner?.name || addPetForOwner.name}'s account!`);
            setAddPetForOwner(null);
          }}
        />
      )}

      {/* Direct Check-In with Vitals Modal */}
      {checkInAppt && (
        <CheckInModal
          appt={checkInAppt}
          db={db}
          setDb={setDb}
          me={me}
          onClose={() => setCheckInAppt(null)}
          onCheckedIn={(vitals) => {
            setCheckInAppt(null);
            say && say(`Patient ${petName(db, checkInAppt.petId)} checked in with vitals! Added to Doctor Queue.`);
          }}
        />
      )}
    </div>
  );
}
